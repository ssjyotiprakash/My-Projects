package com.usa.federal.gov.exception;

import java.util.Date;

import lombok.Data;

@Data
public class ApiError {
	private Integer statusCode;
	private String errorDesc;
	private Date date;
}//class
