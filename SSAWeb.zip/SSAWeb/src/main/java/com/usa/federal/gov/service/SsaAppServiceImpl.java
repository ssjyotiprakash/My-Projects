package com.usa.federal.gov.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usa.federal.gov.entity.SSNMaster;
import com.usa.federal.gov.entity.UsaStateDetails;
import com.usa.federal.gov.exception.SsaAppWebException;
import com.usa.federal.gov.model.SSNModel;
import com.usa.federal.gov.repository.SSNMasterRepository;
import com.usa.federal.gov.repository.UsaStateDetailsRepository;

@Service
public class SsaAppServiceImpl implements SsaAppService {
	public static final Logger logger = LoggerFactory.getLogger(SsaAppServiceImpl.class);

	@Autowired
	private SSNMasterRepository ssnMasterRepo;

	@Autowired
	private UsaStateDetailsRepository usaStateDetailsRepo;

	/**
	 * This method is used to get the SSn number
	 * 
	 * @param model
	 * @return SSN
	 */
	@Override
	public Long ssnEnrollment(SSNModel ssnModel) {

		logger.debug("**ssnEnrollment() method started**");
		// create a entity class object
		SSNMaster ssnMasterEntity = new SSNMaster();

		// copy model data to entity object
		BeanUtils.copyProperties(ssnModel, ssnMasterEntity);

		// setting binary data to entity object
		byte[] image = null;
		try {
			image = ssnModel.getPhoto().getBytes();
			ssnMasterEntity.setPhoto(image);

			logger.debug("**ssnEnrollment() method ended**");
			logger.info("**ssnEnrollment completed successfully**");
		} // try
		catch (IOException e) {
			// TODO: handle exception
			logger.error("**Exception occured in ssnEnrollment()**");
			e.printStackTrace();
		} // catch

		// save Entity
		ssnMasterEntity = ssnMasterRepo.save(ssnMasterEntity);

		// returning ssn
		return ssnMasterEntity.getSsn();
	}// SsnEnrollment

	/**
	 * This method is used to retrive all the ssn details
	 * 
	 * @return models
	 */
	@Override
	public List<SSNModel> retrieveAllSsns() {
		logger.debug("**retrieveAllSsns() method started**");

		// create a new Model array list
		List<SSNModel> models = new ArrayList();

		try {
			// class repository layered method
			List<SSNMaster> entities = ssnMasterRepo.findAll();

			if (!entities.isEmpty()) {
				for (SSNMaster entity : entities) {
					// create a new model class object
					SSNModel model = new SSNModel();

					// copy entity object to model object
					BeanUtils.copyProperties(entity, model);

					// add model obj to model ArrayList
					models.add(model);
				} // for
			} // if
			logger.debug("**retrieveAllSsns() method ended**");
			logger.info("**retrieveAllSsns() completed successfully**");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("**Exception occured in retrieveAllSsns()**");
			e.printStackTrace();
		}
		// returning the model ArrayList obj
		return models;
	}// retrieveAllSsns

	/*@Override
	public List<SSNModel> retrieveAllSsns(Integer pageNum, Integer pageSize) {
		// TODO Auto-generated method stub
		return null;
	}*/

	/**
	 * This method is used to retrive all usa states
	 * 
	 * @return statesList
	 */
	@Override
	public List<String> retrieveAllStates() {
		logger.debug("**retrieveAllStates() method started**");

		// create a new ArrayList of size 60
		List<String> statesList = new ArrayList(60);

		try {
			// call Repository layered method
			List<UsaStateDetails> entities = usaStateDetailsRepo.findAll();

			if (!entities.isEmpty()) {
				for (UsaStateDetails entity : entities) {
					// take the state name from the entity class and add on the ArrayList obj
					statesList.add(entity.getStateName());
				} // for
			} // if
			logger.debug("**retrieveAllStates() method ended**");
			logger.info("**retrieveAllStates() completed successfully**");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("**Exception occured in retrieveAllStates()**");
			e.printStackTrace();
		}
		// return the total stateList
		return statesList;
	}// retrieveAllStates

	/**
	 * This method is used to find state by ssn
	 * 
	 * @param ssn
	 * @return stateName
	 */
	@Override
	public String findStateBySsn(Long ssn) {
		logger.debug("**findStateBySsn() method started**");
		String stateName = null;
		try {
			Optional<SSNMaster> optionalEntity = ssnMasterRepo.findById(ssn);
			if (optionalEntity.isPresent()) {
				SSNMaster entity = optionalEntity.get();
				stateName = entity.getState();

			} // if
			else {
				throw new SsaAppWebException();
			} // else
			logger.debug("**findStateBySsn() method ended**");
			logger.info("**findStateBySsn() completed successfully**");
		} // try
		catch (Exception e) {
			// TODO: handle exception
			logger.error("**Exception occured in findStateBySsn()**");
			e.printStackTrace();
		} // catch
		return stateName;
	}// method
}// class
