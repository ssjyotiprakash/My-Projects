package com.usa.federal.gov.constants;

public class SsaAppConstants {
	public static final String SUCCESS_MSG="successMsg";
	public static final String FAILURE_MSG="failureMsg";
	
	public static final String ENROLL_SUCCESS="enrollSuccess";
	public static final String ENROLL_FAILURE="enrollFailure";
	
	public static final String SSN_MODEL="ssnModel";
	public static final String SSN_MODELS="ssnModels";
	
	public static final String ENROLL_SSN_VIEW="enrollSsn";
	public static final String SSN_DETAILS_VIEW="ssnDetails";
	public static final String ERROR_VIEW="error";
	
	public static final String ERROR_MSG="errorMsg";
	public static final String ERROR_MSG_VALUE="<h5 style='color:red'>Oops! Something went wrong, Please try again after sometime..</h5>";
}//class
