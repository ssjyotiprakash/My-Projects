package com.usa.federal.gov.exception;

public class SsaAppRestException extends Exception{
	
	 public SsaAppRestException() {
		// TODO Auto-generated constructor stub
	 }
	 
	 public SsaAppRestException(String msg) {
			super(msg);
	 }
}//class
