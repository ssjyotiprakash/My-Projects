package com.usa.federal.gov.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name ="USA_STATES_LIST")
@Data
public class UsaStateDetails {
	@Id
	@GeneratedValue(generator ="stateId_seq_gen")
	@SequenceGenerator(
			name ="stateId_seq_gen",
			sequenceName ="stateId_seq",
			initialValue =1,
			allocationSize =1
			)
	@Column(name = "SL_NO")
	private int slNo;
	
	@Column(name ="STATE_CODE")
	private String stateCode;
	
	@Column(name ="STATE_NAME")
	private String stateName;
}//class
