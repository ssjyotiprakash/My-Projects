package com.usa.federal.gov.restcontroller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.usa.federal.gov.exception.SsaAppRestException;
import com.usa.federal.gov.service.SsaAppService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@RestController
@Api(value ="Ssn Rest Controller",description ="This is used to validate SSN")
public class SsnValidateRestController {
	public static final Logger logger=LoggerFactory.getLogger(SsnValidateRestController.class);
	@Autowired
	private SsaAppService ssaAppService;
	
	@ApiOperation(httpMethod ="GET", value = "Get State Name By Ssn",produces ="text/html")
	@GetMapping(value ="/findStateBySsn/{ssn}")
	public String getStateNameBySsn(@PathVariable("ssn") String ssn)throws Exception {
		logger.debug("**getStateNameBySsn() method started**");
		String stateName=null;
		Long convertedSsn=null;
		try {
			convertedSsn=Long.parseLong(ssn);
			stateName=ssaAppService.findStateBySsn(convertedSsn);
			logger.debug("**getStateNameBySsn() method ended**");
			logger.info("**getStateNameBySsn() completed successfully**");
			
		}//try
		catch (Exception e) {
			// TODO: handle exception
			logger.error("**Exception occured in getStateNameBySsn()**");
			throw new SsaAppRestException(e.getMessage());
		}
		return stateName;
	}
}//class
	
	


