package com.usa.federal.gov.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.multipart.MultipartFile;

import lombok.Data;

@Data
public class SSNModel {
    private Long ssn;
    
	private String firstName;
	
	private String lastName;
	
	private String gender;
	
	@DateTimeFormat(pattern ="dd/MMM/yyyy")
	private Date dob;
	
	private String phno;
	
	private String state;
	
	private MultipartFile photo;
	
	private Date createdDate;
	
	private Date updatedDate;
	
	private String createdBy;
	
	private String updatedBy;
}//class
