package com.usa.federal.gov.exception;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.usa.federal.gov.constants.SsaAppConstants;

@Controller
@ControllerAdvice

public class SsaAppGlobalExceptionHandler {
	@ExceptionHandler(value= {SsaAppWebException.class})
	public String handleSsaWebAppException(Model model) {
		model.addAttribute(SsaAppConstants.ERROR_MSG,SsaAppConstants.ERROR_MSG_VALUE);
		return SsaAppConstants.ERROR_VIEW;
	}
	
	/**
	 * This method is used to handle controller class exception
	 * @return response
	 */
	@ExceptionHandler(value = {SsaAppRestException.class})
	public ResponseEntity<ApiError> handleSsaAppRestException() {
		ApiError error=new ApiError();
		error.setStatusCode(HttpStatus.BAD_REQUEST.value());
		error.setErrorDesc("Invalid SSN");
		error.setDate(new Date());
		
		return new ResponseEntity<ApiError>(error,HttpStatus.BAD_REQUEST);
	}

}

