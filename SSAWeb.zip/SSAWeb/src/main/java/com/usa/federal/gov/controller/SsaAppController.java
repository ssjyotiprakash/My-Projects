package com.usa.federal.gov.controller;

import java.util.ArrayList;

import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import com.usa.federal.gov.constants.SsaAppConstants;
import com.usa.federal.gov.exception.SsaAppWebException;
import com.usa.federal.gov.model.SSNModel;
import com.usa.federal.gov.properties.SsaAppProperties;
import com.usa.federal.gov.service.SsaAppService;

@Controller
public class SsaAppController {
	@Autowired
	private SsaAppService ssaAppService;
	@Autowired
	private SsaAppProperties appProps;
	public static final Logger logger = LoggerFactory.getLogger(SsaAppController.class);
	
	
	
	

	/**
	 * This method is used to load SSN Enrollment form
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = { "/", "/enrollSsn" }, method = RequestMethod.GET)
	public String displayEnrollForm(Model model) throws Exception {
		logger.debug("**displayEnrollForm() Method started**");
		try {
			SSNModel ssnModel = new SSNModel();
			model.addAttribute("ssnModel", ssnModel);

			formValues(model);
			logger.debug("**displayEnrollForm() Method ended**");
			logger.info("**ssnForm loaded Successfully**");
		} // try
		catch (Exception e) {
			// TODO: handle exception
			logger.error("**Exception occured in displayEnrollForm**");
			throw new SsaAppWebException();
		} // catch

		return SsaAppConstants.ENROLL_SSN_VIEW;

	}// displayEnrollment
	
	
	

	/**
	 * This method is used to Submit SSN Enrollment form
	 * 
	 * @param ssnModel
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/enrollSsn", method = RequestMethod.POST)
	public RedirectView ssnEnrollment(@ModelAttribute("ssnModel") SSNModel ssnModel, RedirectAttributes redirectAttrs)
			throws Exception {
		// call the service layer method

		logger.debug("**ssnenrollment() method started**");
		try {

			Long ssn = ssaAppService.ssnEnrollment(ssnModel);

			Map<String, String> propsMap = appProps.getSsaProps();

			if (ssn != null && ssn > 0) {
				// success
				// model.addAttribute(SsaAppConstants.SUCCESS_MSG,
				// propsMap.get(SsaAppConstants.ENROLL_SUCCESS));
				redirectAttrs.addFlashAttribute(SsaAppConstants.SUCCESS_MSG,
						propsMap.get(SsaAppConstants.ENROLL_SUCCESS));
			} // if
			else {
				// Failure
				// model.addAttribute(SsaAppConstants.FAILURE_MSG,
				// propsMap.get(SsaAppConstants.ENROLL_FAILURE));
				redirectAttrs.addFlashAttribute(SsaAppConstants.FAILURE_MSG,
						propsMap.get(SsaAppConstants.ENROLL_FAILURE));
			} // else

			// formValues(model);
			 redirectAttrs.addFlashAttribute("ssnModel", new SSNModel());
			logger.debug("ssnenrollment() method ended");
			logger.info("**SSN Enrollment  successfully**");
		} // try
		catch (Exception e) {
			// TODO: handle exception
			logger.error("**Exception occured in ssnEnrollment()**");
			throw new SsaAppWebException();
		} // catch
			// return the logical view name
		//return "redirect:/enrollSuccess";
		return new RedirectView("enrollSuccess",true);
	}// ssnenrollment
	
	
	
	
	

	/**
	 * This method is used to prevent the double posting problem
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/enrollSuccess", method = RequestMethod.GET)
	public String SsnEnrollSuccess(Model model) {
		logger.debug("** SsnEnrollSuccess() started **");
		SSNModel ssnModel = new SSNModel();
		model.addAttribute("ssnModel",ssnModel);
		formValues(model);
		logger.debug("** SsnEnrollSuccess() ended **");
		logger.info("** SsnEnrollSuccess() completed successfully **");
		return SsaAppConstants.ENROLL_SSN_VIEW;
	}
	
	
	
	

	/**
	 * This method is represent for custom form property design type as radio button
	 * and drop down list
	 * 
	 * @param model
	 */
	public void formValues(Model model) {
		// To set Genders as a radio button in form page
		List<String> gendersList = new ArrayList<String>();
		gendersList.add("Male");
		gendersList.add("Female");
		model.addAttribute("genders", gendersList);

		// To set the all states name in form page states box as drop down list
		List<String> statesList = ssaAppService.retrieveAllStates();
		model.addAttribute("statesList", statesList);
	}// formValues
	
	
	
	

	/**
	 * This method is used for dispaly all the ssndetails
	 */
	@RequestMapping(value = "/displaySsnDetails", method = RequestMethod.GET)
	public String displaySsnRecords(Model model) {

		logger.debug("**displaySsnRecords() Method started**");
		try {
			List<SSNModel> ssnModels = ssaAppService.retrieveAllSsns();
			model.addAttribute(SsaAppConstants.SSN_MODELS, ssnModels);

			logger.debug("**displaySsnRecords() Method ended**");
			logger.info("**SsnRecords displayed Successfully**");
		} // try
		catch (Exception e) {
			// TODO: handle exception
			logger.error("**Exception occured in displaySsnRecords**");

			throw new SsaAppWebException();
		} // catch

		return SsaAppConstants.SSN_DETAILS_VIEW;
	}// displaySsnRecords
}// class
