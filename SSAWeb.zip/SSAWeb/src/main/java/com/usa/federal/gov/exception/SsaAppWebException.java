package com.usa.federal.gov.exception;

public class SsaAppWebException extends RuntimeException {

	public SsaAppWebException() {
		
	}
	
	
	public SsaAppWebException(String msg) {
		super(msg);
	}

}
