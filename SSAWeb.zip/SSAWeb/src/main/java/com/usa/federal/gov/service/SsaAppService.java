package com.usa.federal.gov.service;

import java.util.List;

import com.usa.federal.gov.model.SSNModel;

public interface SsaAppService {
	public Long ssnEnrollment(SSNModel ssnModel);
	
	public java.util.List<SSNModel> retrieveAllSsns();
	
	//public java.util.List<SSNModel> retrieveAllSsns(Integer pageNum,Integer pageSize);
	
	public List<String> retrieveAllStates();
	
	public String findStateBySsn(Long ssn);
}
