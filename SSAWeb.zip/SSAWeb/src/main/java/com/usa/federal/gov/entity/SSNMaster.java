package com.usa.federal.gov.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Entity
@Table(name ="SSN_MASTER")
@Data
public class SSNMaster {
	@Id
	@GeneratedValue(generator ="ssn_seq_gen")
	@SequenceGenerator(
			name ="ssn_seq_gen",
			sequenceName ="ssn_seq",
			initialValue =797825496,
			allocationSize =1
			)
	@Column(name ="SSN")
	private Long ssn;
	
	@Column(name ="FIRST_NAME")
	private String firstName;
	
	@Column(name ="LAST_NAME")
	private String lastName;
	
	@Column(name ="GENDER")
	private String gender;
	
	@Column(name ="DOB")
	private Date dob;
	
	@Column(name ="PHONE_NO")
	private String phno;
	
	@Column(name ="STATE")
	private String state;
	
	@Column(name ="PHOTO")
	@Lob
	private byte[] photo;
	
	@Column(name ="CREATED_DATE")
	@Temporal(TemporalType.DATE)
	@CreationTimestamp
	private Date createdDate;
	
	@Column(name ="UPDATED_DATE")
	@Temporal(TemporalType.DATE)
	@UpdateTimestamp
	private Date updatedDate;
	
	@Column(name ="CREATED_BY")
	private String createdBy;
	
	@Column(name ="UPDATED_BY")
	private String updatedBy;
}//class
