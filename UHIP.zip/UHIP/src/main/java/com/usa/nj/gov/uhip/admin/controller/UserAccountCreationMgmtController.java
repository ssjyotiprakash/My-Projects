package com.usa.nj.gov.uhip.admin.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.usa.nj.gov.uhip.admin.exception.AdminException;
import com.usa.nj.gov.uhip.admin.model.UserAccount;
import com.usa.nj.gov.uhip.admin.service.UserAccountMgmtService;
import com.usa.nj.gov.uhip.admin.util.UhipAppConstants;
import com.usa.nj.gov.uhip.admin.util.UhipAppProperties;

@Controller
public class UserAccountCreationMgmtController {
	
	private static final Logger logger=LoggerFactory.getLogger(UserAccountCreationMgmtController.class);
	
	@Autowired
	private UserAccountMgmtService service;
	
	@Autowired
	private UhipAppProperties uhipProps;
	
	HttpSession session;
	
	
	/**
	 * This method is used for load the Login Form
	 * @param model
	 * @return
	 */
	@RequestMapping(value= {"/","createLoginForm"},method=RequestMethod.GET)
	public String loadLoginForm(Model model) {
		logger.debug("** loadLoginForm() started **");
		try {
			//create model class object
			UserAccount userAcc=new UserAccount();
			//Add to model attribute
			model.addAttribute(UhipAppConstants.USER_ACC_MODEL,userAcc);
			logger.debug("** loadLoginForm() ended **");
			logger.info("** loadLoginForm() completed successfully **");
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Some problem occured in loadLoginForm()"+e.getMessage());
			throw new AdminException();
		}//catch
		return UhipAppConstants.LOGIN_FORM_VIEW;
	}//loadLoginForm
	
	
	/**
	 * This method is used for login the form
	 * @param userAcc
	 * @param model
	 * @return
	 * @throws Exception
	 */
	
	@RequestMapping(value="/createLoginForm",method=RequestMethod.POST)
	public String loginForm(HttpServletRequest req,Model model,RedirectAttributes redirectAttrs)throws Exception{
		logger.debug("** loginForm() started **");
		String view="";
		try {
			//getting the email and password from the request
			String formEmail=req.getParameter("email");
			String formPwd=req.getParameter("password");
			
			//call service layer method
			UserAccount userAccModel=service.findByEmail(formEmail);
			
			if(userAccModel !=null) {
				//check the password is valid or not
				if(formPwd.equals(userAccModel.getPassword())) {
					//password is valid--check Status
					String accSw=userAccModel.getActiveSwitch();
					if(accSw.equals(UhipAppConstants.ACTIVE_SWITCH)) {
						String formRole=userAccModel.getRole();
						
						//setting role in session
						//session.setAttribute("role",formRole);
						
						//checking user role
						if(formRole.equals("Admin")) {
							//redirect to admin dashBoard
							view="redirect:/admindashBoard";
						}else {
							//redirect to case worker dashBoard
							view="redirect:/caseWorkerDashBoard";
						}//
					}else {
						//invalid credentials
						logger.info("** Your account is de-activated,contact to Admin **");
						view="redirect:/createLoginForm";
					}
				}else{
				//invalid credentials
					logger.info("** You have entered wrong password **");
					view="redirect:/createLoginForm";
			       }
			   }else{
					//invalid credentials no account find with this email
				   logger.info("** No userAcount is exist with this emailId **");
				   view="redirect:/createLoginForm";
				}
			logger.debug("** loginForm() ended **");
			logger.info("** loginForm() completed successfuly **");
				
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Some problem occured in loginForm()"+e.getMessage());
			throw new AdminException();
		}//catch
		return  view;
		
	}//loginForm()
	
	
	
	/**
	 * This method is used for load the admindashBoard
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/admindashBoard")
	public String loadAdminDashBoard(Model model) {
		logger.debug("** loadAdminDashBoard() started **");
		try {
			//create model class object
			UserAccount userAcc=new UserAccount();
			model.addAttribute(UhipAppConstants.USER_ACC_MODEL,userAcc);
			logger.debug("** loadAdminDashBoard() ended **");
			logger.info("** loadAdminDashBoard() completed successfully **");
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Some problem occured in loadAdminDashBoard()"+e.getMessage());
			throw new AdminException();
		}//catch
 		return UhipAppConstants.ADMIN_DASH_BOARD;
	}//loadAdminDashBoard()
	
	/**
	 * this method is used for display the caseWorkerDashBoard
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/caseWorkerDashBoard")
	public String loadCaseWorkerDashBoard(Model model) {
		logger.debug("** loadCaseWorkerDashBoard() started **");
		try {
			UserAccount userAcc=new UserAccount();
			model.addAttribute(UhipAppConstants.USER_ACC_MODEL,userAcc);
			logger.debug("** loadCaseWorkerDashBoard() ended **");
			logger.info("** loadCaseWorkerDashBoard() completed successfully **");
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Some problem occured in loadCaseWorkerDashBoard()"+e.getMessage());
			throw new AdminException();
		}//catch
		return UhipAppConstants.CASE_WORKER_DASH_BOARD;
	}//loadCaseWorkerDashBoard()

}
