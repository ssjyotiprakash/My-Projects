package com.usa.nj.gov.uhip.admin.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

import lombok.Data;

@Entity
@Table(name = "USER_ACCOUNT")
@Data
public class UserAccountEntity {
	@Id
	@SequenceGenerator(name = "USER_ACC_SEQ", initialValue = 1, allocationSize = 1, sequenceName = "USER_ACC_SEQ_GEN")
	@GeneratedValue(generator = "USER_ACC_SEQ_GEN")
	private int userAccId;
	
	@Column(name = "firstName")
	private String firstName;

	@Column(name = "LastName")
	private String lastName;

	@Column(name = "SSN")
	private Long ssn;

	@Column(name = "Gender")
	private String gender;

	@Column(name = "DOB")
	private Date dob;

	@Column(name = "Email")
	private String email;
	
	@Column(name="active_Switch")
	private String activeSwitch;
	
	@Column(name="Role")
	private String role;

	@Column(name = "password")
	private String password;

	@Column(name = "created_Date")
	@CreationTimestamp
	private Date createdDate;

	@Column(name = "updated_Date")
	@CreationTimestamp
	private Date updatedDate;

	@Column(name = "created_By")
	private String createdBy;

	@Column(name = "updated_By")
	private String updatedBy;

}
