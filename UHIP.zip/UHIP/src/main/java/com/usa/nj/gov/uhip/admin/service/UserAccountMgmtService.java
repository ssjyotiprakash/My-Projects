package com.usa.nj.gov.uhip.admin.service;

import com.usa.nj.gov.uhip.admin.model.UserAccount;

public interface UserAccountMgmtService {
	
	public UserAccount findByEmail(String email);

}
