package com.usa.nj.gov.uhip.admin.repository;

import java.io.Serializable;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.usa.nj.gov.uhip.admin.entity.UserAccountEntity;
@Repository
public interface UserAccountRepository extends JpaRepository<UserAccountEntity, Serializable>  {
	
	
	
	/*@Query(value="select count(email) from UserAccountEntity where email=:email")
	public Integer findByEmail(String email);*/
	
    @Transactional
    @Modifying
    @Query("UPDATE UserAccountEntity entity SET entity.activeSwitch = :activeSwitch WHERE entity.userAccId = :userAccId")
	public Integer updateByUserAccId(String activeSwitch,int userAccId);
	
	
	@Query(value="from UserAccountEntity where email=:emailId")
	public UserAccountEntity findByEmail(String emailId);
	
}


	
	
	





