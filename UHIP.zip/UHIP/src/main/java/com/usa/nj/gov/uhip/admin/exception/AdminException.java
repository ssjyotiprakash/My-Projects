package com.usa.nj.gov.uhip.admin.exception;

public class AdminException extends RuntimeException {
	public AdminException() {
		
	}

	public AdminException(String msg) {
		super(msg);
	}

}
