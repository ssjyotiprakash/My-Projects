package com.usa.nj.gov.uhip.admin.service;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usa.nj.gov.uhip.admin.entity.UserAccountEntity;
import com.usa.nj.gov.uhip.admin.exception.AdminException;
import com.usa.nj.gov.uhip.admin.model.UserAccount;
import com.usa.nj.gov.uhip.admin.repository.UserAccountDetailsRepository;
import com.usa.nj.gov.uhip.admin.repository.UserAccountRepository;
import com.usa.nj.gov.uhip.admin.util.MailService;
import com.usa.nj.gov.uhip.admin.util.UhipAppConstants;
import com.usa.nj.gov.uhip.admin.util.UhipAppProperties;

@Service
public class UserAccountServiceImpl implements UserAccountService {

	public static final Logger logger = LoggerFactory.getLogger(UserAccountServiceImpl.class);
	@Autowired
	private UserAccountRepository userRepo;
	@Autowired
	private UserAccountDetailsRepository userDetailsrepo;
	@Autowired
	private MailService mailService;
	@Autowired
	private UhipAppProperties props;

	@Override
	public boolean createUserAccount(UserAccount userAcc) {
		boolean isSaved = false;
		logger.debug("**createUserAccount()method is started **");
		try {
			UserAccountEntity entity = new UserAccountEntity();
			// copy proprties model obj to model
			BeanUtils.copyProperties(userAcc, entity);
			entity.setActiveSwitch(UhipAppConstants.ACTIVE_SWITCH);
			// save entity
			entity = userRepo.save(entity);
			// check the userId is creted or not
			if (entity.getUserAccId() > 0)
				sendAccCreationEmail(userAcc);
			isSaved = true;

			logger.debug("createUserAccount()method is ended");
			logger.info("createUserAccount()method is completed");
		} catch (Exception e) {
			logger.error("createUserAccount()method has some problem ! Please try again later");
			throw new AdminException(e.getMessage());
		}
		return isSaved;
	}

	/**
	 * This method is used to call MailService class method
	 * 
	 * @param to
	 * @param to
	 */
	private void sendAccCreationEmail(UserAccount userAcc) {
		String subject = props.getUhipProps().get(UhipAppConstants.MAIL_SUBJECT);
		String body = getAccCreationEmailBodyContent(userAcc);
		mailService.sendSimpleMessage(userAcc.getEmail(), subject, body);
	}

	/**
	 * This method is used for read the file value
	 */
	private String getAccCreationEmailBodyContent(UserAccount userAcc) {

		FileReader fr = null;
		BufferedReader br = null;
		StringBuffer sb = new StringBuffer("");
		String fileName = props.getUhipProps().get(UhipAppConstants.BODY_TEXT_FILE);
		logger.debug("** getAccCreationEmailBodyContent() started **");
		try {
			fr = new FileReader(fileName);
			br = new BufferedReader(fr);
			String line = br.readLine();

			while (line != null) {
				// process the line

				if (line.equals("") || !line.contains("$")) {
					sb.append(line);
					// read the next line
					line = br.readLine();
					continue;
				}

				if (line.contains("${FIRSTNAME}")) {
					line = line.replace("${FIRSTNAME}", userAcc.getFirstName());
				}
				if (line.contains("${LASTNAME}")) {
					line = line.replace("${LASTNAME}", userAcc.getLastName());
				}
				if (line.contains("${URL}")) {
					line = line.replace("${URL}", UhipAppConstants.APPLICATION_URL);
				}
				if (line.contains("${EMAIL}")) {
					line = line.replace("${EMAIL}", userAcc.getEmail());
				}
				if (line.contains("${PASSWORD}")) {
					line = line.replace("${PASSWORD}", userAcc.getPassword());
				}
				if (line.contains("${ROLE}")) {
					line = line.replace("${ROLE}", userAcc.getRole());
				}
				if (line.contains("${PHNO}")) {
					String phno = props.getUhipProps().get(UhipAppConstants.ADMINSTRATOR_MOB_NO);
					line = line.replace("${PHNO}", phno);
				}

				sb.append(line);

				// read next line
				line = br.readLine();
				logger.debug("** getAccCreationEmailBodyContent() ended **");
				logger.info("** getAccCreationEmailBodyContent() completed successfully **");
			}
		} catch (Exception e) {
			// TODO: handle Exception
			logger.error("getAccCreationEmailBodyContent() method has some problem ! Please try again later");
			e.printStackTrace();
			throw new AdminException();
		} // catch
		finally {
			if (br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			if (fr != null) {
				try {
					fr.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		return sb.toString();
	}
	
	
	/**
	 * This method is used for retrieve all Accounts
	 */

	@Override
	public List<UserAccount> retrieveAllAccounts() {
		logger.debug("**retrieveAllAccounts() method started**");

		// create a new Model array list
		List<UserAccount> models = new ArrayList();

		try {
			// class repository layered method
			List<UserAccountEntity> entities = userDetailsrepo.findAll();

			if (!entities.isEmpty()) {
				for (UserAccountEntity entity : entities) {
					// create a new model class object
					UserAccount model = new UserAccount();

					// copy entity object to model object
					BeanUtils.copyProperties(entity, model);

					// add model obj to model ArrayList
					models.add(model);
				} // for
			} // if
			logger.debug("**retrieveAllAccounts() method ended**");
			logger.info("**retrieveAllAccounts() completed successfully**");
		} catch (Exception e) {
			// TODO: handle exception
			logger.error("**Exception occured in retrieveAllAccounts()**");
			e.printStackTrace();
			throw new AdminException();
		}
		// returning the model ArrayList obj
		return models;
	}// retrieveAllSsns

	

	/*@Override
	public List<UserAccount> retrieveAllAccounts(Integer pageNum, Integer pageSize) {
		// TODO Auto-generated method stub
		return null;
	}*/
	
	
	/**
	 * This method is used to validate the email is unique or duplicate
	 * @param email
	 * @return
	 */
	/*@Override
	public String validateEmail(String email) {
		logger.debug("** validateEmail() started **");
		Integer count=0;
		try {
			//call persistence layered method
			count=userRepo.findByEmail(email);
			
			if(count>=1) {
				logger.warn("** Duplicate email found **");
			}
			
			logger.debug("** validateEmail() ended **");
			logger.info("** validateEmail() completed successfully **");
		}catch(Exception e) {
			//TODO: handle Exception
			logger.error("Error occured in validateEmail():"+e.getMessage());
			throw new AdminException();
		}
		return (count>=0) ? UhipAppConstants.DUPLICATE : UhipAppConstants.UNIQUE;
	}//validateEmail
*/
	
	@Override
	public boolean editForm(UserAccount userAcc) {
		logger.debug("** editForm() started **");
		//cretae UserAccountEntity class object
		UserAccountEntity entity=new UserAccountEntity();
		
		//copy properties from model to entity
 		BeanUtils.copyProperties(userAcc, entity);
 		try {
 			//call repository layer method
 			entity=userRepo.save(entity);
 			
 			if(entity.getUserAccId()>0) {
 				return true;
 			}
 		}catch(Exception e) {
		// TODO Auto-generated method stub
 			logger.error("Some problem occured in editForm()"+e.getMessage());
 			throw new AdminException();
	}
 		return false;
	}//editForm()

	@Override
	public UserAccount findUserAccByUserId(Integer userAccId) {
		logger.debug("** findUserAccByUserId() started **");
		
		//create model class object
		UserAccount userAcc=new UserAccount();
		try {
			//call repository layer method
			Optional<UserAccountEntity> optionalEntity=userRepo.findById(userAccId);
			
			if(optionalEntity.isPresent()) {
				UserAccountEntity entity=optionalEntity.get();
				
				//copy properties from entity to model
				BeanUtils.copyProperties(entity,userAcc);
			}else {
				logger.warn("Given userAccId is not valid");
				throw new AdminException();
			}
			logger.debug("** findUserAccByUserId() ended **");
			logger.info("** findUserAccByUserId() completed successfully **");
		}catch(Exception e) {
			logger.error("Some problem occured in findUserAccByUserId()"+e.getMessage());
			throw new AdminException();
		}
		// TODO Auto-generated method stub
		return userAcc;
	}//findUserAccByUserId()

	

	@Override
	public Integer updateUserAccByUserId(String activeSw,int userAccId) {
		logger.debug("** updateUserAccByUserId() started **");
		int count=0;
		try {
			//call repository method
			count=userRepo.updateByUserAccId(activeSw,userAccId);
			
			if(count>0) {
				logger.debug("** successfully updated **");
			}else {
				logger.debug("** Updation failed **");
			}
			logger.debug("** updateUserAccById() ended **");
			logger.info("** updateUserAccById() completed **");
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Some problem occured in updateUserAccByUser()"+e.getMessage());
			throw new AdminException();
		}
		// TODO Auto-generated method stub
		return count;
	}

	
}//class

