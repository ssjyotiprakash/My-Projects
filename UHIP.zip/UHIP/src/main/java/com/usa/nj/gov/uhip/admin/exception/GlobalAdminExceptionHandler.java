package com.usa.nj.gov.uhip.admin.exception;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.usa.nj.gov.uhip.admin.util.UhipAppConstants;

@Controller
@ControllerAdvice
public class GlobalAdminExceptionHandler {
	
	@ExceptionHandler(value= {AdminException.class})
	public String handleAdminException(Model model) {
		model.addAttribute(UhipAppConstants.ERROR_MSG,UhipAppConstants.ERROR_MSG_VALUE);
		return UhipAppConstants.ERROR_VIEW;
		
	}

}
