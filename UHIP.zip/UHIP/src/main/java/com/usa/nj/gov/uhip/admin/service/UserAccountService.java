package com.usa.nj.gov.uhip.admin.service;


import com.usa.nj.gov.uhip.admin.model.UserAccount;

public interface UserAccountService {
	public boolean createUserAccount(UserAccount userAcc);
	
public java.util.List<UserAccount> retrieveAllAccounts();
	
	//public java.util.List<UserAccount> retrieveAllAccounts(Integer pageNum,Integer pageSize);

//public String validateEmail(String email);

public boolean editForm(UserAccount userAcc);

public UserAccount findUserAccByUserId(Integer userAccId);

public Integer updateUserAccByUserId(String activeSw,int userAccId);

}
