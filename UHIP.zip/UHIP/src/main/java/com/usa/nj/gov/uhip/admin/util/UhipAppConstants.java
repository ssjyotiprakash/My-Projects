package com.usa.nj.gov.uhip.admin.util;

public class UhipAppConstants {
	
	public static final String INVALID_CREDENTIALS="invalidCredentials";
	public static final String ACCOUNT_DEACTIVATE="accountDeactivate";
	
	public static final String USER_ACC_MODEL="userAccountModel";
	public static final String USER_ACC_CREATION_VIEW="userAccount";
	
	public static final String SUCCESS_MESSAGE="successMessage";
	public static final String FAILURE_MESSAGE="failureMessage";
	
    public static final String ACCOUNT_CREATED_SUCCESSFULLY="accountCreatedSuccessfully";
    public static final String ACCOUNT_CREATION_FAIL="accountCreationFail";
    
    public static final String ERROR_MSG="errorMsg";
	public static final String ERROR_MSG_VALUE="<center><h3 style='color:red'>Oops! Something went wrong, Please try again after sometime..</h3></center>";
	
	public static final String ERROR_VIEW="errorView";
	
	public static final String ACTIVE_SWITCH="y";
	
	public static final String MAIL_SUBJECT="subject";
	public static final String ADMINSTRATOR_MOB_NO="uhipAdminMobNo";
	public static final String BODY_TEXT_FILE="filename";
	public static final String APPLICATION_URL="http://localhost:6060/UHIP/";
	
	public static final String ACCOUNT_DETAILS_VIEW="accountDetails";
	
	public static final String DUPLICATE="duplicateEmail";
	public static final String UNIQUE="uniqueEmail";
	
	public static final String EDIT_FORM_PAGE="editForm";
	
	public static final String UPDATE_SUCCESS_MSG="AccountUpdatedSuccessfully";
	public static final String UPDATE_FAILURE_MSG="AccountUpdationFailed";  
	
	public static final String LOGIN_FORM_VIEW="loginForm";
	public static final String ADMIN_DASH_BOARD="adminDashBoard";
	public static final String CASE_WORKER_DASH_BOARD="caseWorkerDashBoard";
	

	

	
	

}
