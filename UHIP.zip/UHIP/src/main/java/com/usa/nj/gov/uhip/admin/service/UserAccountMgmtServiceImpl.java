package com.usa.nj.gov.uhip.admin.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.usa.nj.gov.uhip.admin.entity.UserAccountEntity;
import com.usa.nj.gov.uhip.admin.exception.AdminException;
import com.usa.nj.gov.uhip.admin.model.UserAccount;
import com.usa.nj.gov.uhip.admin.repository.UserAccountRepository;


@Service
public class UserAccountMgmtServiceImpl implements UserAccountMgmtService {
	
	private static final Logger logger=LoggerFactory.getLogger(UserAccountMgmtServiceImpl.class);
	
	@Autowired
	private UserAccountRepository userRepo;

	/*@Override
	public UserAccount findByEmail(String email) {
		logger.debug("** findByEmail() started **");
		//create model class object
		UserAccount userAcc=new UserAccount();
		try {
			//create entity class object
			UserAccountEntity entity=new UserAccountEntity();
			
			//call repository layer method
			entity=userRepo.findByEmail(userAcc.getEmail());
					
			//copy the properties from entity to model
			BeanUtils.copyProperties(entity,userAcc);
			
			logger.debug("** findByEmail() ended **");
			logger.info("** findByEmail() completed successfully **");
			
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Some problem occured in findByEmail()"+e.getMessage());
			throw new AdminException();
		}//catch
		return userAcc;
	}*///findByEmail
	
	
	@Override
	public UserAccount findByEmail(String email) {
		logger.debug("** findByEmail() started **");
		//create model class object
		UserAccount userAcc=new UserAccount();
		UserAccountEntity entity=null;
		try {
			//call repository layer method
			entity=userRepo.findByEmail(email);
			if(entity!=null) {
			//copy the properties from entity to model
			BeanUtils.copyProperties(entity,userAcc);
			
			logger.debug("** findByEmail() ended **");
			logger.info("** findByEmail() completed successfully **");
			}else {
			  logger.debug("There is no userAccount found with this email");
			}
			
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Some problem occured in findByEmail()"+e.getMessage());
			throw new AdminException();
		}//catch
		return userAcc;
	}//findByEmail

}//UserAccountMgmtServiceImpl
