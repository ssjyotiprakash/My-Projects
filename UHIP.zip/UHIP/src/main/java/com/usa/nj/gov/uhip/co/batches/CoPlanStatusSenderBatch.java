package com.usa.nj.gov.uhip.co.batches;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.usa.nj.gov.uhip.co.model.CoBatchRunDetailsModel;
import com.usa.nj.gov.uhip.co.model.CoTriggersModel;
import com.usa.nj.gov.uhip.co.service.CoBatchService;
import com.usa.nj.gov.uhip.ed.model.EligibilityDetailModel;

public class CoPlanStatusSenderBatch {

	private static final String BATCH_NAME = "CO_PLAN_STATUS_SENDER";

	private static Integer SUCC_TRIGGERS = 0;
	private static Integer FAIL_TRIGGERS = 0;

	@Autowired
	private CoBatchService coBatchService;

	public void preProcess() {
		// Insert batch start time with status as ST in
		// (BATCH_RUN_DETAILS)
		CoBatchRunDetailsModel model = new CoBatchRunDetailsModel();
		model.setBatchName(BATCH_NAME);
		model.setBatchRunStatus("ST");
		model.setStartDate(new Date());

		coBatchService.insertBatchRunDetails(model);
	}

	public void start() {
		List<CoTriggersModel> triggers = coBatchService.findAllPendingTriggers();
		if (!triggers.isEmpty()) {
			// -------------MT start -----------
			for (CoTriggersModel trigger : triggers) {
				process(trigger);
			}
			// -------------MT End----------------
		}
	}

	public void process(CoTriggersModel trigger) {
		try {
			// from trigger get case number
			long caseNo = trigger.getCaseNum();

			// using case num read eligibility data --- 1
			EligibilityDetailModel edModel = coBatchService.findByCaseNum(caseNo);

			// from elig data identify elig status
			String planStatus = edModel.getPlanStatus();

			// Based Status -- generate pdf
			if (planStatus.equals("AP")) {
				buildApPdf();
			} else if (planStatus.equals("DN")) {
				buildDnPdf();
			} else {
				buildTnPdf();
			}
			coBatchService.storePdf(null);

			// send pdf in email
			sendPdfEmail();

			// update trigger as completed ---- 3
			coBatchService.updateTrgStatus(trigger.getTriggerId(), "C");

			SUCC_TRIGGERS++;

		} catch (Exception e) {
			FAIL_TRIGGERS++;
		}
	}

	private void buildDnPdf() {
		// TODO Auto-generated method stub
	}

	private void buildApPdf() {
		// TODO Auto-generated method stub

	}

	private void buildTnPdf() {
		// TODO Auto-generated method stub

	}

	private void sendPdfEmail() {
		// TODO Auto-generated method stub
	}

	public void postProcess() {
		// Generate Batch summary report and insert in DB (BATCH_SUMMARY)
		// update batch run status as EN in (BATCH_RUN_DETAILS)
	}

}
