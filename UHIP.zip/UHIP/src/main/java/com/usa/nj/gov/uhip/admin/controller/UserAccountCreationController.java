package com.usa.nj.gov.uhip.admin.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.usa.nj.gov.uhip.admin.exception.AdminException;
import com.usa.nj.gov.uhip.admin.model.UserAccount;
import com.usa.nj.gov.uhip.admin.service.UserAccountService;
import com.usa.nj.gov.uhip.admin.util.UhipAppConstants;
import com.usa.nj.gov.uhip.admin.util.UhipAppProperties;



@Controller
public class UserAccountCreationController {
	
	@Autowired
	private UhipAppProperties properties;
	
	@Autowired
	private UserAccountService service;
	
	private static final Logger logger=LoggerFactory.getLogger(UserAccountCreationController.class); 
	
	
	/**
	 * This method is used to lunch the form page
	 * @param model
	 * @return
	 */
	@RequestMapping(value ="createUserAcc",method=RequestMethod.GET)
			                
	public String loadAccCreationForm(Model model) {
		logger.debug("** loadAccCreationForm() started **");
		try {
		//cretae UserAccount object
		UserAccount userAcc=new UserAccount();
		model.addAttribute(UhipAppConstants.USER_ACC_MODEL,userAcc);
		
		
		initializeFormValues(model);
		logger.debug("** loadAccCreationForm() ended **");
		logger.info("** AccCreation Form loaded successfully **");
		
		}//try
		catch(Exception e){
		//TODO: handle Exception
			logger.error("** Exception occured in loadAccCreationForm() **"+e.getMessage());
			throw new AdminException();
	}//catch
		return UhipAppConstants.USER_ACC_CREATION_VIEW;
	}
	
	
	/**
	 * This method is represent for custom form property design type as radio button
	 * and drop down list for role
	 * @param model
	 */
	
	public void initializeFormValues(Model model) {
		// To set Genders as a radio button in form page
				List<String> gendersList = new ArrayList<String>();
				gendersList.add("Male");
				gendersList.add("Female");
				model.addAttribute("genders", gendersList);

				// To set the all roles in form page role box as drop down list
				List<String> roleList = new ArrayList<String>();
				roleList.add("Case Worker");
				roleList.add("Admin");
				model.addAttribute("role",roleList);
	}
	
	
	/**
	 * This method is used for creating the UserAccount
	 * @param userAcc
	 * @param model
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value="/createUserAcc",method=RequestMethod.POST)
	
	public String createUserAccount(@ModelAttribute("userAccountModel") UserAccount userAcc,RedirectAttributes redirectAttrs)throws Exception {
		
		logger.debug("** createUserAccount() started **");
		try {
			//call service layer method
			boolean isSaved=service.createUserAccount(userAcc);
			
			//call the UhipAppProperties layer method
			Map<String,String> uhipProps=properties.getUhipProps();
			
			if(isSaved=true) {
				//success msg
				redirectAttrs.addFlashAttribute(UhipAppConstants.SUCCESS_MESSAGE,uhipProps.get(UhipAppConstants.ACCOUNT_CREATED_SUCCESSFULLY))	;
				//model.addAttribute("success", "Registered successfully");
				}
			else {
				//Failure msg
				redirectAttrs.addFlashAttribute(UhipAppConstants.FAILURE_MESSAGE,uhipProps.get(UhipAppConstants.ACCOUNT_CREATION_FAIL));
				//model.addAttribute("failure", "Registration Failured");
			}
			
			//initializeFormValues(model);
			redirectAttrs.addFlashAttribute(UhipAppConstants.USER_ACC_MODEL, new UserAccount());
			logger.debug("** createUserAccount() ended");
			
		}catch(Exception e){
			//TODO: handle Exception
			logger.error("** Exception occured in createUserAccount() **"+e.getMessage());
			throw new AdminException();
		}
		
		logger.info("** createUserAccount() ended successfully **");
		return "redirect:/accRegSuccess";
		
	}
	
	/**
	 * This method is used to display Success Message
	 * @param model
	 * @return
	 */
	@RequestMapping(value="/accRegSuccess",method=RequestMethod.GET)
	public String accRegSuccess(Model model) {
		logger.info("** accRegSuccess() called **");
		UserAccount userAcc=new UserAccount();
		model.addAttribute(UhipAppConstants.USER_ACC_MODEL,userAcc);

		initializeFormValues(model);
		return UhipAppConstants.USER_ACC_CREATION_VIEW;
		
	}
	

	/**
	 * This method is used for dispaly all the Accounts
	 */
	@RequestMapping(value = "/displayAccounts", method = RequestMethod.GET)
	public String displayAccounts(Model model) {

		logger.debug("**displaySsnRecords() Method started**");
		try {
			List<UserAccount> userAcc = service.retrieveAllAccounts();
			model.addAttribute(UhipAppConstants.USER_ACC_MODEL, userAcc);

			logger.debug("**displaySsnRecords() Method ended**");
			logger.info("**SsnRecords displayed Successfully**");
		} // try
		catch (Exception e) {
			// TODO: handle exception
			logger.error("**Exception occured in displaySsnRecords**");

			throw new AdminException();
		} // catch

		return UhipAppConstants.ACCOUNT_DETAILS_VIEW;
	}// displaySsnRecords
	
	/**
	 * This method is used for check the Email
	 * @param req
	 * @return
	 */
	
	/*@RequestMapping(value="createUserAcc/checkEmail",method=RequestMethod.GET)
	public @ResponseBody String checkEmail(HttpServletRequest req) {
		logger.debug("** checkEmail() started **");
		String response=null;
		try {
			//get email from the request scope
			String email=req.getParameter("email");
			
			if(email==null || "".equals(email)) {
				logger.error("** Email is missing in the request **");
			}
			
			//call the service layer method
			response=service.validateEmail(email);
			
			logger.debug("** checkEmail() ended **");
			logger.info("** checkEmail() completed successfully **");
		}catch(Exception e) {
			//TODO:handle Exception
			logger.error("Error occured in checkEmail():"+e.getMessage());
			throw new AdminException();
		}
		//return response body
		return response;
	}//checkEmail*/
	
	
	/**
	 * This method is used for edit the form
	 * @param req
	 * @param model
	 * @return
	 */
	@RequestMapping(value="editForm",method=RequestMethod.GET)
	public String editForm(HttpServletRequest req,Model model) {
		logger.debug("** editForm() started **");
		try {
			//get userAccId from the request scpoe
			Integer userAccId=Integer.parseInt(req.getParameter("userAccId"));
			
			//call service layer method
			UserAccount userAcc=service.findUserAccByUserId(userAccId);
			
			//add the userAcc model data in request scope
			model.addAttribute(UhipAppConstants.USER_ACC_MODEL,userAcc);
			
			//pass the form values for display gender and role
			initializeFormValues(model);
			
			logger.debug("** editForm() ended **");
			logger.info("** editForm() completed successfully **");
		}catch(Exception e) {
			//TODO:exception handling
			logger.error("Some problem occured in editForm()"+e.getMessage());
			throw new AdminException();
		}
		
		return UhipAppConstants.EDIT_FORM_PAGE;
	}//editForm()
	
	
	
	/**
	 * This method is used form update the form
	 * @param userAcc
	 * @param model
	 * @return
	 */
	@RequestMapping(value="editForm",method=RequestMethod.POST)
	public String updateEditForm(@ModelAttribute("userAccountModel") UserAccount userAcc,Model model) {
		logger.debug("** updateeditForm started **");
		boolean status=false;
		try {
			status=service.editForm(userAcc);
			if(status=true) {
				//success msg
				model.addAttribute(UhipAppConstants.UPDATE_SUCCESS_MSG,"updation success");
			}else {
				//failure msg
				model.addAttribute(UhipAppConstants.UPDATE_FAILURE_MSG, "updation failure");
			}
			//for gender and role
			initializeFormValues(model);
			logger.debug("** updateEditForm() ended **");
			logger.info("** updateEditForm() completed successfully **");
		}catch(Exception e) {
			//TODO:exception handling
			logger.error("Some problem occured in updateEditForm"+e.getMessage());
			throw new AdminException();
		}//catch
		return UhipAppConstants.EDIT_FORM_PAGE;
	}//updateEditForm()
	
	
	/**
	 * This method is used for activate the UserAccount
	 * @param userAcc
	 * @param model
	 * @return
	 */
	@RequestMapping(value="activateAcc",method=RequestMethod.GET)
	public String activateSwitch(HttpServletRequest req,Model model) {
		logger.debug("** activateSwitch() started **");
		Integer count=0;
		try {
			//read the value from the request scope
			Integer userAccId=Integer.parseInt(req.getParameter("userAccId"));
			
			//call service layer method
			count=service.updateUserAccByUserId("y",userAccId);
			if(count>0) {
				logger.debug("updated successfuly");
			}else {
				logger.debug("updation failure");
			}
			//for gender and role
			initializeFormValues(model);
			logger.debug("** activateSwitch() ended **");
			logger.info("** activateSwitch() completed successfully **");
		}catch (Exception e) {
			// TODO: handle exception
			logger.error("Some problem occured in activateSwitch()"+e.getMessage());
			throw new AdminException();
		}//catch
		return "redirect:/displayAccounts";
	}//activateSwitch()
	
	
	/**
	 * This method is used for de active the UserAccount
	 * @param req
	 * @param model
	 * @return
	 */
	@RequestMapping(value="deActivateAcc",method=RequestMethod.GET)
	public String deActivateSwitch(HttpServletRequest req,Model model) {
		logger.debug("** deActivateSwitch() ** started");
		
		int userAccId=Integer.parseInt(req.getParameter("userAccId")); 
		try {
		int count=service.updateUserAccByUserId("n",userAccId);
		logger.debug("** deActivateSwitch() ended **");
		logger.info("** deActivateSwitch() completed successfully **");
	}catch (Exception e) {
		// TODO: handle exception
		logger.error("Some problem occured in deActivateSwitch()"+e.getMessage());
		throw new AdminException();
	}
		return "redirect:/displayAccounts";
	}//deActivateSwitch()
	
	
}
	