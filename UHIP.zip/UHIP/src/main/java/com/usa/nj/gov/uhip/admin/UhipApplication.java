package com.usa.nj.gov.uhip.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UhipApplication {

	public static void main(String[] args) {
		SpringApplication.run(UhipApplication.class, args);
	}

}
