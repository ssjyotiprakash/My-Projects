package com.usa.nj.gov.uhip.admin.model;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;
@Data
public class UserAccount {
	private int userAccId;
	
	private String firstName;
	
	private String lastName;
	
	private Long ssn;
	
	private String gender;
	
	@DateTimeFormat(pattern ="dd/MMM/yyyy")
	private Date dob;
	
	private String email;
	
	private String role;
	
	private String activeSwitch;
	
	private String password;
	
	private Date createdDate;
	
	private Date updatedDate;
	
	private String createdBy;
	
	private String updatedBy;
	

}
